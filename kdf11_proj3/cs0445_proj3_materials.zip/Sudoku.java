import java.util.List;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Sudoku {
	static boolean isFullSolution(int[][] board) {
		// TODO: Complete this method
		return false;
	}

	static boolean reject(int[][] board) {
		// TODO: Complete this method
		return true;
	}

	static int[][] extend(int[][] board) {
		// TODO: Complete this method
		return null;
	}

	static int[][] next(int[][] board) {
		// TODO: Complete this method
		return null;
	}

	static void testIsFullSolution() {
		// TODO: Complete this method
	}

	static void testReject() {
		// TODO: Complete this method
	}

	static void testExtend() {
		// TODO: Complete this method
	}

	static void testNext() {
		// TODO: Complete this method
	}

	static void printBoard(int[][] board) {
		if(board == null) {
			System.out.println("No assignment");
			return;
		}
		for(int i = 0; i < 9; i++) {
			if(i == 3 || i == 6) {
				System.out.println("----+-----+----");
			}
			for(int j = 0; j < 9; j++) {
				if(j == 2 || j == 5) {
					System.out.print(board[i][j] + " | ");
				} else {
					System.out.print(board[i][j]);
				}
			}
			System.out.print("\n");
		}
	}

	static int[][] readBoard(String filename) {
		List<String> lines = null;
		try {
			lines = Files.readAllLines(Paths.get(filename), Charset.defaultCharset());
		} catch (IOException e) {
			return null;
		}
		int[][] board = new int[9][9];
		int val = 0;
		for(int i = 0; i < 9; i++) {
			for(int j = 0; j < 9; j++) {
				try {
					val = Integer.parseInt(Character.toString(lines.get(i).charAt(j)));
				} catch (Exception e) {
					val = 0;
				}
				board[i][j] = val;
			}
		}
		return board;
	}

	static int[][] solve(int[][] board) {
		if(reject(board)) return null;
		if(isFullSolution(board)) return board;
		int[][] attempt = extend(board);
		while (attempt != null) {
			int[][] solution = solve(attempt);
			if(solution != null) return solution;
			attempt = next(attempt);
		}
		return null;
	}

	public static void main(String[] args) {
		if(args[0].equals("-t")) {
			testIsFullSolution();
			testReject();
			testExtend();
			testNext();
		} else {
			int[][] board = readBoard(args[0]);
			printBoard(board);
			System.out.println("Solution:");
			printBoard(solve(board));
		}
	}
}

